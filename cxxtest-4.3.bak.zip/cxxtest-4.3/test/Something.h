#include <string>

inline std::string something() { return "something"; }
