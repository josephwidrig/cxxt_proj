// This simple source file is just used to verify that the compiler works

int main()
{
    return 0;
}
