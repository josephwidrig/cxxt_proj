// time_mock.cpp
#define CXXTEST_MOCK_TEST_SOURCE_FILE
#include <time_mock.h>
